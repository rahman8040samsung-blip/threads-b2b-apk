package com.example.data

data class VersionInfo(
    val versionCode: Long = 0L,
    val latestVersion: String = "",
    val apkUrl: String = "",
    val releaseNotes: String = "",
    val published: Boolean = false,
    val forceUpdate: Boolean = false
)
